<?php

namespace Usuarios\PreferenciasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UsuariosPreferenciasBundle extends Bundle
{
}
