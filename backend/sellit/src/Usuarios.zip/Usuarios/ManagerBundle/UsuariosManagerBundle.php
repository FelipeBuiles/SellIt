<?php

namespace Usuarios\ManagerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UsuariosManagerBundle extends Bundle
{
}
