<?php

namespace Productos\ImagenesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductosImagenesBundle extends Bundle
{
}
