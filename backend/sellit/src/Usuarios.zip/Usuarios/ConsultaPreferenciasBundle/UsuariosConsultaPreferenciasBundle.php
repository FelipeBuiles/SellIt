<?php

namespace Usuarios\ConsultaPreferenciasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UsuariosConsultaPreferenciasBundle extends Bundle
{
}
