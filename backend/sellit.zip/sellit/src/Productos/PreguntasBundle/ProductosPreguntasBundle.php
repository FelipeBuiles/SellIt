<?php

namespace Productos\PreguntasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductosPreguntasBundle extends Bundle
{
}
