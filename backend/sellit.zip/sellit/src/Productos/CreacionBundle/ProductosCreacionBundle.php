<?php

namespace Productos\CreacionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductosCreacionBundle extends Bundle
{
}
