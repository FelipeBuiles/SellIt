<?php

namespace Application\GenericoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ApplicationGenericoBundle extends Bundle
{
}
