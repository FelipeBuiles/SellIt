<?php

namespace Productos\NegociacionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductosNegociacionBundle extends Bundle
{
}
