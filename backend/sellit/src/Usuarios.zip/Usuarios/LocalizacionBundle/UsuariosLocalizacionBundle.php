<?php

namespace Usuarios\LocalizacionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UsuariosLocalizacionBundle extends Bundle
{
}
